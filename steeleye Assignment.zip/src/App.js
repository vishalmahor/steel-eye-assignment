import "./styles.css";
import List from "./List";
export default function App() {
  return (
    <div className="App">
      <List />
    </div>
  );
}
